//Brandtly Strobeck Fall 2017
//This will be a LinkedList, similar to the one found in the java API, built from the ground up
//no option to test clear(),size(),toString(), since darn near each method utilizes it.
//Something of note is that the thrown exceptions rarely print in the console where the are supposed to. Not sure why...
import java.awt.List;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Scanner;

public class LinkedListTester
{
	static Scanner KB = new Scanner(System.in);
	
	public static void main(String[] args)
	{
		runProgram();
	}

	public static void runProgram()
	{
		int option = 0;
		
		//option = menu(KB);
		while(option != 69)
		{
			option = menu(KB);
			if(option == 1)
			{
				System.out.println();
				testAdd();
				
				option = 0;
			}
			if(option == 2)
			{
				System.out.println();
				testAddIndex();
				
				option = 0;
			}
			if(option == 3)
			{
				System.out.println();
				testAddCollection();
				
				option = 0;
			}
			if(option == 4)
			{
				System.out.println();
				testAddCollectionIndex();
				
				option = 0;
			}
			if(option == 5)
			{
				System.out.println();
				testContains();
				
				option = 0;
			}
			if(option == 6)
			{
				System.out.println();
				testContainsAll();
				
				option = 0;
			}
			if(option == 7)
			{
				System.out.println();
				testGet();
				
				option = 0;
			}
			if(option == 8)
			{
				System.out.println();
				testIndexOf();
				
				option = 0;
			}
			if(option == 9)
			{
				System.out.println();
				testLastIndexOf();
				
				option = 0;
			}
			if(option == 10)
			{
				System.out.println();
				testRemove();
				
				option = 0;
			}
			if(option == 11)
			{
				System.out.println();
				testRemoveIndex();
				
				option = 0;
			}
			if(option == 12)
			{
				System.out.println();
				testRemoveAll();
				
				option = 0;
			}
			if(option == 13)
			{
				System.out.println();
				testToArray();
				
				option = 0;
			}
			if(option == 14)
			{
				testHashCode();
				
				option = 0;
			}
			if(option == 15)
			{
				testClone();
				
				option = 0;
			}
			if(option == 16)
			{
				testEquals();
				
				option = 0;
			}
			if(option == 17){
				testRetainAll();
				
				option = 0;
			}
			if(option == 18)
			{
				testIterator();
				
				option = 0;
			}
			if(option == 19) {
				testSet();
				
				option = 0;
			}
			if(option == 20)
			{
				testSubList();
				
				option = 0;
			}
			if(option == 69)
			{
				exit();
			}
		}
		
		
		
	}//close runProgram()	

	private static int menu(Scanner KB) {
		
		int myOption = 0;
		while(myOption != 1 && myOption != 2 && myOption != 69 && myOption != 3 && myOption != 4 && myOption != 5 && myOption != 6 && myOption !=7 && myOption != 8 && myOption != 9 && myOption != 10 && myOption != 11 && myOption != 12 && myOption != 13 && myOption != 14 && myOption != 15 && myOption != 16 && myOption != 17 && myOption != 18 && myOption != 19 && myOption != 20) // list of valid options
		{
			System.out.println("       +---------------------+");
			System.out.println("       |        ~MENU~       |");
			System.out.println("       +---------------------+");
			System.out.println("\tEnter a number");
			System.out.println("1) test add(Object obj)");
			System.out.println("2) test addIndex(int index, Object obj)");
			System.out.println("3) test addAll(Collection c)");
			System.out.println("4) test addAll(int index, Collection c)");
			System.out.println("5) test contains(Object obj)");
			System.out.println("6) test containsAll(Collection c)");
			System.out.println("7) test get(int index)");
			System.out.println("8) test indexOf(Object obj)");
			System.out.println("9) test lastIndexOf(Object obj)");
			System.out.println("10) test remove(Object data)");
			System.out.println("11) test remove(int index)");
			System.out.println("12) test removeAll(Collection c)");
			System.out.println("13) test toArray()");
			System.out.println("14) test hashCode()");
			System.out.println("15 test clone()");
			System.out.println("16) test equals()");
			System.out.println("17) test retainAll(Collection c");
			System.out.println("18) test Iterator");
			System.out.println("19) test set(int index, Object data)");
			System.out.println("20) test subList()");
			System.out.println("69) quit");
			myOption = KB.nextInt();
			KB.nextLine();

				
		}
		return myOption;
	}
	
	private static LinkedList createList()
	{
		LinkedList myList = new LinkedList();
		//System.out.println("Testing add method");
		myList.add("Monday");
		myList.add("Tuesday");
		myList.add("Wednesday");
		myList.add("Thursday");
		myList.add("Friday");
		myList.add("Saturday");
		myList.add("Sunday");
		return myList;
	}
	private static void testAdd()
	{
		try {
		LinkedList myList = createList();
	
		System.out.println(myList);
		System.out.println("List size: " + myList.size());
		
		
		myList.add(null);
		
		System.out.println(myList);
		System.out.println("List size: " + myList.size());
		myList.clear();
		}
		catch(Exception e)
		{
			System.out.println("Failed to add NULL data, and exception as caught");
			e.printStackTrace();
			System.out.println("====================================");
			runProgram();
		}
	}
	private static void testAddIndex()
	{
		try 
		{
			LinkedList myList = createList();
			System.out.println("Testing addIndex method at indexes 0, 4, and last index");
			myList.add(0,"42");
			myList.add(4,"Heratio Cane");
			myList.add(myList.size() -1,"69");
			System.out.println(myList);
			System.out.println("List size: " + myList.size());
			System.out.println("Catching IndexOutOfBoundsException");
			myList.add(-1,"FAIL");
			System.out.println(myList);
			System.out.println("List size: " + myList.size());
			myList.clear();
		}
		catch(Exception e)
		{
			//System.out.println("====================================");
			e.printStackTrace();
			System.out.println("====================================");
			runProgram();
		}
	}
	
	private static void testAddCollection() 
	{
		try
		{
			LinkedList myList = createList();
			System.out.println("Testing addAll(Collection c) method");
			System.out.println("List before adding from array list \n" + myList);
			ArrayList<String> myara = new ArrayList<String>();
			myara.add("October");
			myara.add("November");
			myara.add("December");
			
			myList.addAll(myara);
			System.out.println("List after adding from array list");
			System.out.println(myList + "\n List size: " + myList.size());
		
			myList.addAll(null);
			myList.clear();
			
			
		}
		catch(Exception e)
		{
			
			e.printStackTrace();
			System.out.println("====================================");
			runProgram();
		}
		
	}
	
	private static void testAddCollectionIndex() {
		try
		{
			LinkedList myList = createList();
			System.out.println("Testing addAll(Collection c) method");
			System.out.println("List before adding from array list" + myList);
			ArrayList<String> myara = new ArrayList<String>();
			myara.add("October");
			myara.add("November");
			myara.add("December");
			
			myList.addAll(2,myara);
			System.out.println("List after adding from array list");
			System.out.println(myList + "\n List size: " + myList.size());
			System.out.println();
			
			myList.addAll(0,null);
			myList.add(-1,myara);
			myList.clear();
		}
		catch(NullPointerException e)
		{
			System.out.println("Exception is catchng trying to add a null array list");
			e.printStackTrace();
			System.out.println("====================================");
			runProgram();
		}
		catch(IndexOutOfBoundsException e)
		{
			System.out.println("Exception is catchng Index Out Of Bounds");
			e.printStackTrace();
			System.out.println("====================================");
			runProgram();
		}
	}
	
	private static void testContains() 
	{
		LinkedList myList = createList();
		System.out.println(myList);
		String success = "Friday";
		boolean test = myList.contains(success);
		if(test)
		{
			System.out.println("Testing list for Friday");
			System.out.println("Object is in the list");
		}
			
		else
		{
			System.out.println("Object not in list");
		}
		String fail = "Spaghetti";
		test = myList.contains(fail);
		if(test)
		{
			System.out.println("Objest is in the list");
		}
		else
		{
			System.out.println("Testing list for Spaghetti");
			System.out.println("Object is not in the list");
		}
		myList.clear();
		
	}
	
	private static void testContainsAll()
	{
		try {
			LinkedList myList = createList();
			ArrayList<String> myAra = new ArrayList<String>();
			System.out.println(myList);
		
			myAra.add("Monday");
			myAra.add("Friday");
			System.out.println("Collection: " + myAra);
		
			boolean test = myList.containsAll(myAra);
			if(test)
			{
				System.out.println("List does not contains the collection!");
			}
			else
			{
				System.out.println("List contain the collection!");
			}
			System.out.println();
			ArrayList<String> ara = new ArrayList<String>();
			ara.add("Pabst");
			ara.add("Blue");
			ara.add("Ribbon");
			System.out.println("Checking list for new collection: " + ara);
			test =myList.containsAll(ara);
			if(test)
			{
				System.out.println("List does contain the collection!");
			}
			else
			{
				System.out.println("List does not contain the collection");
			}
			System.out.println();
			System.out.println("Attempting to pass a null collection");
			myList.containsAll(null);
			myList.clear();
		}
		catch(NullPointerException e)
		{
			System.out.println("Null element not accepted");
			e.printStackTrace();
			System.out.println("====================================");
			runProgram();
		}
		
	}
	
	private static void testGet()
	{
		try
		{
			LinkedList myList = createList();
			Object index =  myList.get(2);
			System.out.println(myList);
			System.out.println("Getting object at index 2");
			System.out.println("Object at index: " + index);
			
			System.out.println("Attempting to get index of -1");
			index =  myList.get(-1);
			myList.clear();
			
		}
		catch(IndexOutOfBoundsException e)
		{
			e.printStackTrace();
			System.out.println("====================================");
			runProgram();
		}
	}
	
	private static void testIndexOf()
	{
		LinkedList myList = createList();
		System.out.println(myList);
		
		int index = myList.indexOf("Thursday");
		System.out.println("The index of Thursday is at index: " + index);
		
		index = myList.indexOf("Banana");
		System.out.println("The index of Banana is at index: " + index);
		myList.clear();
		
	}
	
	private static void testLastIndexOf()
	{
		LinkedList myList = createList();
		myList.add("Monday");
		System.out.println(myList);
		
		int index = myList.lastIndexOf("Monday");
		System.out.println("Last index of Monday: " + index);
		index = myList.lastIndexOf("Tarzan");
		
		System.out.println("Last index of Tarzan: "+index);
		myList.clear();
	}
	
	private static void testRemove()
	{
		LinkedList myList = createList();
		System.out.println(myList);
		String success = "Friday";
		boolean test = myList.remove(success);
		if(test)
		{
			System.out.println("Removing " + success + " from list");
			System.out.println(myList);
			System.out.println("List size: " + myList.size());
		}
			
		else
		{
			System.out.println("Object failed to be removed");
		}
		
		String fail = "Spaghetti";
		test = myList.remove(fail);
		if(test)
		{
			System.out.println("Removed " + fail + " from list");
		}
		else
		{
			
			System.out.println("Failed to remove " + fail + " from list");
			System.out.println(myList);
		}
		myList.clear();
	}
	
	private static void testRemoveIndex()
	{
		try
		{
			LinkedList myList = createList();
			System.out.println(myList);
			
			Object remove1 = myList.remove(0);
			Object remove2 = myList.remove(3);
			Object remove = myList.remove(myList.size() -1);
			
			System.out.println("Removing Indexes 0, 3, and end of list");
			System.out.println(myList + "\nNew size " + myList.size());
			
			System.out.println("Attemptint to remove item outside of index range");
			remove = myList.remove(99);
			myList.clear();
		}
		catch(IndexOutOfBoundsException e)
		{
			e.printStackTrace();
			System.out.println("====================================");
			runProgram();
		}
		
	}
	
	
	private static void testRemoveAll()
	{
		try
		{
			LinkedList myList = createList();
			ArrayList<String> myara = new ArrayList<String>();
			myara.add("Monday");
			myara.add("Tuesday");
			myara.add("Friday");
			
			System.out.println("List before deleting from collection");
			System.out.println(myList);
			myList.removeAll(myara);
			System.out.println("List after deleting from collection \n" +myList+ "\n List size: " + myList.size());
			//ArrayList<String> ara = new ArrayList<String>();
			System.out.println("Attempting to remove a null collection");
			myList.removeAll(null);
		}
		catch (NullPointerException e)
		{
			e.printStackTrace();
			System.out.println("====================================");
			runProgram();
		}
		
		
	}
	
	private static void testToArray()
	{
		LinkedList myList = createList();
		
		Object[] myAra = myList.toArray();
		
		for(Object obj: myAra)
		{
			System.out.println(obj);
		}
		System.out.println("Array hash code: " +myAra.hashCode());
		System.out.println("Linked List hash code: " + myList.hashCode());
		System.out.println("Thus, the two lists are different.");
		myList.clear();
	}
	private static void testHashCode()
	{
		LinkedList myList = createList();
		System.out.println("Printing Linked List's hash code");
		System.out.println(myList.hashCode());
	}
	private static void testClone()
	{
		LinkedList myList = createList();
		
		LinkedList clone = (LinkedList) myList.clone();
		
		System.out.println("Checking cloned list for equality to master list");
		boolean test = myList.equals(clone);
		if(test)
		{
			System.out.println("The clone is a shallow copy of the master");
			System.out.println("Master hash code " + myList.hashCode());
			System.out.println("Clone hash code "+clone.hashCode());
		}
		myList.clear();
		clone.clear();
		
	}
	private static void testEquals()
	{
		LinkedList myList = createList();
	
		LinkedList myList2 = new LinkedList();
		myList2.add("420");
		myList2.add("Youthberry");
		myList2.add("A E S T H E T I C");
		
		System.out.println(myList);

		System.out.println(myList2);
		boolean test = myList.equals(myList2);
		if(test)
		{
			System.out.println("The two are equal");
		}
		else
		{
			System.out.println("The two are not equal");
		}
		LinkedList clone = (LinkedList) myList2.clone();
		System.out.println("Cloning master list");
		test = myList2.equals(clone);
		if(test)
		{
			System.out.println("The two are equal");
		}
		else
		{
			System.out.println("The two are not equal");
		}
	}
	

	private static void testRetainAll()
	{
		try{
			LinkedList myList = createList();
			System.out.println(myList);
			ArrayList<String> myAra = new ArrayList<String>();
			myAra.add("Monday");
			myAra.add("Sunday");
			
			System.out.println("Collection to retain: " + myAra);

			myList.retainAll(myAra);
			System.out.println("New List" + "\n"+myList);
			
			System.out.println("Attempting to pass a null list");
			
			myList.retainAll(null);
			myList.clear();
		}
		catch(NullPointerException e)
		{
			e.printStackTrace();
			System.out.println("====================================");
			runProgram();
		}
	}
	private static void testIterator()
	{
		LinkedList myList = createList();
		System.out.println("Utilizing enhanced for loop to use iterator methods for printing");
		for(Object obj: myList)
		{
			System.out.println(obj);
		}
		System.out.println("\nCheck tester source code to see that iterator does nothing on an empty Array List");
		ArrayList<String> myAra = new ArrayList<String>();
		
		for(Object o: myAra)
		{
			System.out.println(o);
		}
	}
	

	private static void testSet() 
	{
		try
		{
			LinkedList myList = createList();
			System.out.println("Unaltered list before set() is done");
			System.out.println(myList);
			System.out.println("Setting new node at index 0, index 3, and last index");
			Object n1 = myList.set(0, "Sponge Bob");
			Object n2 = myList.set(3, "Patrick");
			Object n3 = myList.set(myList.size() - 1, "Mr. Krabbs");
			
			System.out.println("Nodes replaced: " + n1 + ", " + n2 + ", " + n3);
			System.out.println("New List: " + "\n" + myList);
			System.out.println("Attemptiont to add at wrong index...");
			myList.set(-1, "Failure");
			myList.clear();
		}
		catch(IndexOutOfBoundsException e)
		{
			e.printStackTrace();
			System.out.println("====================================");
			runProgram();
		}
		
	}


	private static void exit()
	{			
		System.out.println("Exiting...\nThanks for playing!");
		KB.close();			
		KB = null;
		System.exit(0);
			
	}
	
	private static void testSubList() {
		try
		{
			LinkedList myList = createList();
			System.out.println("Master List \n" + myList);
			LinkedList sub = (LinkedList) myList.subList(1, 4);//not sure why type cast is needed but shout out to eclipse for always being there to pick up my slack ^^
			System.out.println("Sub List from index 1 to 4\n" + sub);
			
			System.out.println("Attempting to pass in a bogus index of 4 to 1");
			sub.clear();
			sub = (LinkedList) myList.subList(4, 1);
			System.out.println(sub);
			myList.clear();
		}
		catch(IndexOutOfBoundsException e)
		{
			e.printStackTrace();
			System.out.println("====================================");
			runProgram();
		}
	}
}

//	
