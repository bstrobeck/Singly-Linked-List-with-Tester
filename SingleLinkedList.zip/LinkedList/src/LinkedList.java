//Brandtly Strobeck Fall 2017
//This will be a LinkedList, similar to the one found in the java API, built from the ground up
import java.io.Serializable;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.NoSuchElementException;

public class LinkedList implements Cloneable, Serializable, List
{
	private class Node
	{
		private Object data;
		private Node next;
		
		public Node(Object data, Node next)//singly linked list with a dummy head
		{
			this.data = data;
			this.next = next;
		}
		
		public Node()
		{
			this(null, null);
		}
	
	}//end nested Node
	
	private class LinkedListIterator implements Iterator//nexted iterator class
	{
		private Node cur;
		
		public LinkedListIterator(Node start)
		{
			this.cur = start;
		}
		
		public boolean hasNext()
		{
			return this.cur != null;
		}
		
		public Object next()
		{
			if(hasNext())
			{
				Object data = cur.data;
				cur = cur.next;
				return data;
			}
			throw new NoSuchElementException("There was nothing to be found...");
		}
	}//end nested Iterator
	
	private Node head;//variables for LL
	private int size;
	
	public LinkedList()
	{
		this.head = new Node();// makes dummy node
		this.head.next = this.head;//next refers to dummy
		this.size = 0;
	}//ctor
	
	public Node find(int index)// helper method to find nodes by index
	{
		Node curr = head.next;
		for(int i = 0; i < index; i++)
		{
			curr = curr.next;
		}
		return curr;
	}

	@Override
	public boolean add(Object data)//adds to end of list WORKS
	{
		if(this.size == 0)//first to be added
		{
			Node newNode = new Node(data,null);
			head.next = newNode;
			
			size++;
			return true;
		}
		Node curr = this.head.next;
		while(curr.next != null)
		{
			curr = curr.next;
		}
		Node newNode = new Node(data, null);
		curr.next = newNode;
		size++;
		return true;	
	}
	

	@Override
	public void add(int index, Object data)//adds at specified index WORKS
	{
		if(index < 0 || index >= this.size)
		{
			throw new IndexOutOfBoundsException("The given index of " + index + " was not valid.");
		}
		else
		{
			if(index == 0)
			{
				Node newNode = new Node(data,head.next);
				head.next = newNode;
				
			}
			else
			{
				Node temp = find(index);
				Node newNode = new Node(data,temp);
				Node prev = find(index - 1);
				prev.next = newNode;
			}
			size++;
		}
	}

	@Override
	public boolean addAll(Collection c)//WORKS
	{
		if(c == null)//this check does nothing it seems....
		{
			return false;
		}
		
		for(Object data: c)
		{
			add(data);
			size++;
		}
		return true;
	}

	@Override
	public boolean addAll(int index, Collection c)//WORKS
	{
		
		if(c == null)
		{
			return false;
		}
		if(index < 0 || index >= this.size)
		{
			throw new IndexOutOfBoundsException("The given index of " + " was not valid.");
		}
		
		if(index == 0)
		{
			int i = 0;
			for(Object data: c)
			{
				add(i,data);//could lose the whole rest of the list stay tuned
				i++;
				
			}
		}
		
		else
		{
			Node prev = find(index - 1);
			Node cur = find(index);
		
			for(Object data: c)
			{
				Node newNode = new Node(data, null);
				prev.next = newNode;
				prev = prev.next;
				if(prev.next == null)
				{
					prev.next = cur;
				}
				size++;
			}
		}
		return true;
	}

	@Override
	public void clear()//WORKS
	{
		this.head.next = null;
		this.size = 0;

	}

	@Override
	public boolean contains(Object toFind)//WORKS
	{
		for(Node curr = head.next; curr != null; curr = curr.next)
		{
			if(curr.data.equals(toFind))
			{
				return true;
			}
		}
		
		return false;
	}

	@Override
	public boolean containsAll(Collection c)//needs work still help me somebody
	{
		if(c.contains(null))
		{
			throw new NullPointerException("Null element not accepted.");
		}
		for(Object obj: c)
		{
			for(Object obj1: this)
			{
				if(!contains(c))
				{
					return false;
				}
			}
		}
		return true;
//	
	}

	@Override
	public Object get(int index)//WORKS
	{
		if(index < 0 || index >= this.size)
		{
			throw new IndexOutOfBoundsException("The given index of " + index + "was not valid.");
		}
		else
		{
			Node toFind = find(index);
			return toFind.data;
		}
	}

	@Override
	public int indexOf(Object toFind)//WORKS
	{
		int i = 0;
		for(Node curr = head.next; curr != null; curr = curr.next)
		{
			if(curr.data.equals(toFind))
			{
				return i;
			}
			i++;
		}
		return -1;
	}

	@Override
	public boolean isEmpty()//WORKS
	{
		if(this.size == 0)
		{
			return true;
		}
		return false;
	}

	@Override
	public Iterator iterator()//WORKS
	{
		return new LinkedListIterator(this.head.next);
	}

	@Override
	public int lastIndexOf(Object toFind)//WORKS
	{
		Node curr = this.head.next;
		int indexCounter = 0;
		int lastIndex = -1;
		while(curr != null)
		{
			if(curr.data.equals(toFind))
			{
				 lastIndex = indexCounter;
			}
			curr = curr.next;
			indexCounter++;
		}
		return lastIndex;
	}

	@Override
	public ListIterator listIterator()
	{
		throw new UnsupportedOperationException("Not needed on this assignment.");
	}

	@Override
	public ListIterator listIterator(int arg0)
	{
		throw new UnsupportedOperationException("Not needed on this assignment.");
	}

	@Override
	public boolean remove(Object data)//WORKS
	{
		if(isEmpty() == true)
		{
			return false;
		}
		
		Node curr = this.head.next;
		Node prev = this.head;
		while(curr != null)
		{
			if(curr.data.equals(data))
			{
				prev.next = curr.next;
				size--;
				return true;
			}
			curr = curr.next;
			prev = prev.next;
		}
		return false;	
	}

	@Override
	public Object remove(int index)//WORKS
	{
		if(index < 0 || index >= this.size)
		{
			throw new IndexOutOfBoundsException("The given index of " + index + " was not valid.");
		}
		
		if(index == 0)
		{
			Node temp = this.head.next;
			this.head.next = temp.next;
			size--;
			return temp.data;
		}
		Node prev = find(index - 1);
		Node toRemove = find(index);
		prev.next = toRemove.next;
		size--;
		return toRemove.data;
	}

	@Override
	public boolean removeAll(Collection c)//WORKS
	{
		if(c.contains(null))
		{
			throw new NullPointerException("Null pointer not accepted.");
		}
		
		for(Object data: c)
		{
			remove(data);
		}
		return true;
	}

	@Override
	public boolean retainAll(Collection c)//do not be fooled this does not work yet
	{
		if(c.contains(null))
		{
			throw new NullPointerException("Null elements not supported.");
		}
			
		LinkedList temp = new LinkedList();
		for(Object obj: c)
		{
			for(Object obj1: this)
			{
				if(obj.equals(obj1))
				{
					temp.add(obj1);
				}
			}
		}
		this.size = temp.size;
		this.head.next = temp.head.next;
		return true;
	}

	@Override
	public Object set(int index, Object data)//WORKS
	{
		if(index < 0 || index > this.size)
		{
			throw new IndexOutOfBoundsException("The given index of " + " is not valid.");
		}
		if(index == 0)
		{
			Node newNode = new Node(data, null);
			Node temp = this.head.next;
			this.head.next = newNode;
			newNode.next = temp.next;
			return temp.data;
		}
		Node prev = find(index - 1);
		Node cur = find(index);
		Node newNode = new Node(data,cur.next);
		prev.next = newNode;
		return cur.data;//returns the data at the node that was replaced!
	}

	@Override
	public int size()//WORKS
	{
		return this.size;
	}

	@Override
	public LinkedList subList(int fromIndex, int toIndex)//WORKS
	{
		if(fromIndex < 0 || toIndex < fromIndex || fromIndex >= this.size || toIndex >=this.size)
		{
			throw new IndexOutOfBoundsException("One or both indexes are not valid. From Index: " + fromIndex + " To Index: " + toIndex);
		}
		
		LinkedList myList = new LinkedList();//super class reference to a sub class object
		
		int stop = toIndex;
		int start = fromIndex;
		Node last = find(toIndex);
		
		while(stop > start)// a stupid way of doing it, having two counters... but it works!
		{
			for(Node temp = find(start); temp != last; temp = temp.next)
			{
				myList.add(temp.data);
				start++;
			}
			stop--;
		}
		return myList;
	}

	@Override
	public Object[] toArray()//WORKS
	{
		Object[] myAra = new Object[this.size];
		
		Node cur = this.head.next;
		int i = 0;
		while(cur != null)
		{
			myAra[i] = cur.data;
			i++;
			cur = cur.next;
		}
		return myAra;
	}

	@Override
	public Object[] toArray(Object[] arg0)//WORKS
	{
		 throw new UnsupportedOperationException("Not required on this assignment");
	}
	
	@Override
	public String toString()//WORKS
	{
		String result = "";
		for(Node curr = head.next;curr != null; curr = curr.next)
			result += curr.data + "\n";
		return result;
	}
	
	@Override
	public int hashCode()//WORKS
	{
		int result = 0;
		for(Node curr = this.head.next;curr != null; curr = curr.next)
		{
			result += curr.data.hashCode();
		}
		return result;
	}
	
	@Override
	public boolean equals(Object other)//WORKS... kinda
	{
		if(other == null)
			return false;
		if(!(other instanceof LinkedList))
			return false;
		
		LinkedList that = (LinkedList) other;
		if(this == that)//checks physical memory address
			return true;
		
		Node thisCurr;
		Node thatCurr;
		
		for(thisCurr = this.head.next,thatCurr = that.head.next;thisCurr != null; thisCurr = thisCurr.next, thatCurr = thatCurr.next)
		{
				if(!thisCurr.data.equals(thatCurr.data))
					return false;
			
		}
		return true;
	}
	
	@Override
	public Object clone()//WORKS
	{
		LinkedList copy = new LinkedList();
		for(Object data: this)
		{
			copy.add(data);
		}
		return copy;
	}

}